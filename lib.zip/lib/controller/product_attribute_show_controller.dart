import 'package:get/get.dart';

import '../model/model_attribute_drop_down_value.dart';

class AttributeController extends GetxController{

  var selectedAttributeDataList1 = RxList<ModelAttributeData>.empty(growable: true);




}