
const String splashIcon = "assets/images/app_icon.png";

// intro images
const String intro_1 = "assets/images/intro_1.png";
const String intro_2 = "assets/images/intro_2.png";
const String intro_3 = "assets/images/intro_3.png";

// login background
const String loginBackground = "assets/images/login_background.png";
const String iconLock = "assets/icons/padlock.png";
