class IntroModel {
  String? image;
  String? title;
  String? description;

  IntroModel({
    this.image,
    this.title,
    this.description,
  });
}
