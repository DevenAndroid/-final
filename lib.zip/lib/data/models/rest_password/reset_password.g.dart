// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'reset_password.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$_ResetPassword _$$_ResetPasswordFromJson(Map<String, dynamic> json) =>
    _$_ResetPassword(
      status: json['status'] as String?,
      message: json['message'] as String?,
    );

Map<String, dynamic> _$$_ResetPasswordToJson(_$_ResetPassword instance) =>
    <String, dynamic>{
      'status': instance.status,
      'message': instance.message,
    };
