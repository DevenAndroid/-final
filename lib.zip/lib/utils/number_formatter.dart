import 'package:intl/intl.dart';

final numberFormatTwoDecimal = NumberFormat('#,##0.00', 'en_US');
